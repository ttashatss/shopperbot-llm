
#Drive Key
DRIVE_KEY_PATH = '/Users/tashatanarugsachock/Desktop/shopperbot-llm/keys/final-project-416207-ad7093210fab.json'
DRIVE_FOLDER_ID = '1xel40pZr5phLc0xA9brhk_vyOHLQ8LFW'

#OpenAI Key
OPENAI_API_KEY = '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'

#Pinecone Key
PINECONE_API_KEY = '8d7e9758-a8ae-4647-b43f-d5751940a72b'
INDEX_NAME = 'final1'